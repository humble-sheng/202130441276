import Utils.mailUtils;
public class sendEmail
{
	public static void main(String[] args)
	{
		mailUtils.sendMail("1743734139@163.com", "123456");
	}
}
