package beans;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

public class creator {

    public static String generateCreateTableSQL(Class<?> beanClass, String tableName) {
        StringBuilder sql = new StringBuilder("CREATE TABLE " + tableName + " (\n");

        Field[] fields = beanClass.getDeclaredFields();
        for (Field field : fields) {
            if (!Modifier.isStatic(field.getModifiers())) {
                String fieldName = field.getName();
                String fieldType = getSQLType(field.getType());
                sql.append(fieldName).append(" ").append(fieldType).append(",\n");
            }
        }

        // Remove the trailing comma and newline
        sql.delete(sql.length() - 2, sql.length());
        sql.append("\n);");

        return sql.toString();
    }

    private static String getSQLType(Class<?> fieldType) {
        if (fieldType == int.class || fieldType == Integer.class) {
            return "INT";
        } else if (fieldType == long.class || fieldType == Long.class) {
            return "BIGINT";
        } else if (fieldType == float.class || fieldType == Float.class) {
            return "FLOAT";
        } else if (fieldType == double.class || fieldType == Double.class) {
            return "DOUBLE";
        } else if (fieldType == String.class) {
            return "VARCHAR(255)";
        } else {
            // Add more mappings for other data types as needed
            return "VARCHAR(255)";
        }
    }

    public static void main(String[] args) {
        // 替换成你的Bean类和表名
        Class<?> beanClass = shopToCustomerBean.class;
        String tableName = "shopToCustomer";

        String createTableSQL = generateCreateTableSQL(beanClass, tableName);
        System.out.println(createTableSQL);
    }
}

